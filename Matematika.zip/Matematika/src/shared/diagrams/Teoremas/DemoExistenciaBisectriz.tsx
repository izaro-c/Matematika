/**
 * Placeholder — Diagrama interactivo del Teorema de existencia de la bisectriz.
 * Pendiente de implementación con JSXGraph vía el skill diagrama.
 */
export const DemoExistenciaBisectriz = () => {
  return (
    <div className="w-full h-full min-h-[350px] relative bg-lienzo/40 border border-pizarra/10 rounded-sm overflow-hidden flex items-center justify-center">
      <span className="text-pizarra/30 font-serif italic text-sm">Diagrama en construcción</span>
    </div>
  );
};
